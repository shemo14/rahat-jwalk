import Reactotron from 'reactotron-react-native';

Reactotron.configure({ host : '10.0.0.13', port: 9090 }).useReactNative().connect();







