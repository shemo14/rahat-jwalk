import React, { Component } from 'react';


class DrawerTabs extends Component{
    constructor(props){
        super(props);
    }


    render(){
        return false
    }
}

export default DrawerTabs;