export default {
    url: 'http://rahat.aait-sa.com/api/',
};