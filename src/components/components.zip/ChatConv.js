import React, { Component } from 'react';
import { View, Text, Image, Animated, FlatList, KeyboardAvoidingView, Dimensions, ScrollView } from 'react-native';
import { Button, Icon, Container, Header, Right, Body, Content, Left , Card, CardItem, Thumbnail , Item, Input, Form } from 'native-base';
import { DoubleBounce } from 'react-native-loader';
import axios from 'axios';
import CONST from '../consts';


const width = Dimensions.get('window').width;
const height = Dimensions.get('window').height;
const data = [{'msg': 'test 1'}, {'msg': 'test 1'}, {'msg': 'test 1'}, {'msg': 'test 1'}, {'msg': 'test 1'}, {'msg': 'test 1'}, {'msg': 'test 1'}, {'msg': 'test 1'}]

class ChatConv extends Component{
    constructor(props){
        super(props);
        this.state = {
            data
        }
        // console.log('opspps')
    }

    componentWillMount(){
        console.log('opssssssss pppdpppd');
    }

    static navigationOptions = () => ({
        drawerLabel: ()=> null,
    });

    _keyExtractor = (item, index) => item.id;


    renderItem(item){
       console.log('render index ...', item.index);

        if(item.index % 2 == 0){
            return(
            <View style={{ width: '100%' }}>
            <Card transparent style={{marginBottom:10}} >
                        <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                            <Left>
                                <Thumbnail style={{height:60, width:60 , borderRadius:50 , borderWidth:2 , borderColor:'#fff'}} source={require('../../assets/images/profile.png')}/>
                                
                                <View style={{flex:1 , width:'100%'}}>
                                    <Body style={{backgroundColor:'#fff' , borderWidth:1 , borderRadius:25 , borderTopLeftRadius:2 , borderColor: '#eee', marginLeft:5 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                        <Text note style={{color: '#868686',fontSize: 13 , lineHeight:18}}> مثال لنص مثال لنص مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                    </Body>
                                </View>
                            </Left>
                        </CardItem>
                        <Text note style={{ color: '#868686',fontSize: 13 , alignSelf:'flex-end' , marginHorizontal:20}}>09:05 pm</Text>
                    </Card>
            </View>)
        }else{
            <View style={{ width: '100%' }}>
                <Card transparent style={{marginBottom:10}}>
                            <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                                <Left>
                                    
                                <View style={{flex:1 , width:'100%'}}>
                                        <Body style={{backgroundColor:'#eebc47' , borderWidth:1 , borderRadius:25 , borderTopRightRadius:2 , borderColor: '#eebc47', marginLeft:0 , marginRight:5 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                            <Text note style={{color: '#fff',fontSize: 13 , lineHeight:18}}> مثال لنص مثال لنص مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                        </Body>
                                        
                                    </View>
                                    <Thumbnail style={{height:60, width:60 , borderRadius:50 , borderWidth:2 , borderColor:'#eebc47'}} source={require('../../assets/images/profile.png')}/>
                                    
                                </Left>
                            </CardItem>
                            <Text note style={{ color: '#868686',fontSize: 13 , alignSelf:'flex-start' , marginHorizontal:20}}>09:05 pm</Text>
                        </Card>
            </View>
        }
    }

   
    render(){
        return(
            <Container>
                <Header style={{ height: 70, backgroundColor: '#437c1a', paddingTop: 15 }}>
                    <Right style={{ flex: 0 }}>
                        <Button transparent onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name='menu' type='Entypo' style={{ color: '#fff', fontSize: 30, marginTop: 8, left: -10 }} />
                        </Button>
                    </Right>
                    <Body style={{ width: '100%', alignItems: 'center', alignSelf: 'center' }}>
                    <Text style={{ color: '#fff', textAlign: 'center', marginRight: 20, fontSize: 18 }}>الدردشة</Text>
                    </Body>
                    <Left style={{ flex: 0 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name={'ios-arrow-back'} type='Ionicons' style={{ color: '#fff' }} />
                        </Button>
                    </Left>
                </Header>
                <KeyboardAvoidingView behavior={'position'} style={{width:'100%', flexDirection:'column', flex: 1, zIndex: -1 }}>

                    <ScrollView 
                    ref={ref => this.scrollView = ref}
                    onContentSizeChange={(contentWidth, contentHeight)=>{        
                        this.scrollView.scrollToEnd({animated: true});
                    }}
                    style={{height:height-70 , paddingTop:20, }}>

                    <FlatList
                        data={this.state.data}
                        renderItem={item => this.renderItem(item)}
                        numColumns={2}
                        keyExtractor={this._keyExtractor}
                    />
                    </ScrollView>    
                    <View style={{ backgroundColor:'#fff' , borderTopWidth:3 , borderColor:'#eee' , flexDirection:'row' , flex: 1, width: '100%',height:60, position:'absolute' , bottom:0}}>
                                <Button  rounded style={{ zIndex:-1,backgroundColor: '#eebc47', justifyContent: 'flex-end', height: 45  , width:45 ,borderRadius:50, marginLeft:15 , top:5}}>
                                    <Icon name={'send'} type={'FontAwesome'} style={{  color: "#fff" , fontSize:17 }}/>
                                </Button>
                                <Item  style={{flex:1,zIndex:2222 , borderWidth:1 , borderColor:'#eee', borderRadius:50, height:45 , alignSelf:'flex-end' , marginBottom:5}}>
                                    <Input placeholder="أكتب رسالتك..."
                                           style={{ flex:1, width:'100%', paddingLeft:15 , paddingRight:15,marginRight:15 , borderWidth:1 , borderColor:'#eee', borderRadius:50, paddingBottom:10 , color: '#797979' , textAlign:'right' , backgroundColor:'#fff'}}
                                           placeholderTextColor={{ color: '#a7a7a7' }}
                                    />
                                </Item>
                            </View>
                </KeyboardAvoidingView>
            </Container>
        )
    }
}

const styles={
 
};

export default ChatConv;