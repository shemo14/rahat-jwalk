import React, { Component } from 'react';
import { View, Text, Image, Animated, FlatList, TouchableOpacity, Dimensions } from 'react-native';
import { Button, Icon, Container, Header, Right, Body, Content, Left , Card, CardItem, Thumbnail } from 'native-base';
import { DoubleBounce } from 'react-native-loader';
import axios from 'axios';
import CONST from '../consts';


const width = Dimensions.get('window').width;
class Chat extends Component{
    constructor(props){
        super(props);
        this.state = {
            
        }
    }

    static navigationOptions = () => ({
        drawerLabel: ()=> null,
    });

   
    render(){
        return(
            <Container>
                <Header style={{ height: 70, backgroundColor: '#437c1a', paddingTop: 15 }}>
                    <Right style={{ flex: 0 }}>
                        <Button transparent onPress={() => this.props.navigation.openDrawer()}>
                            <Icon name='menu' type='Entypo' style={{ color: '#fff', fontSize: 30, marginTop: 8, left: -10 }} />
                        </Button>
                    </Right>
                    <Body style={{ width: '100%', alignItems: 'center', alignSelf: 'center' }}>
                    <Text style={{ color: '#fff', textAlign: 'center', marginRight: 20, fontSize: 18 }}>الدردشة</Text>
                    </Body>
                    <Left style={{ flex: 0 }}>
                        <Button transparent onPress={() => this.props.navigation.goBack()}>
                            <Icon name={'ios-arrow-back'} type='Ionicons' style={{ color: '#fff' }} />
                        </Button>
                    </Left>
                </Header>
                <Content>
                    <View style={{ flex :1 , width:'100%' , flexDirection:'column' , paddingTop:10 }}>
                        <Card transparent >
                            <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                                <Left>
                                    <View>
                                        <Thumbnail style={{height:70, width:70 , borderRadius:50}} source={require('../../assets/images/profile.png')}/>
                                        <View style={{backgroundColor:'#fff' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:0,justifyContent:'center' , alignItems:'center'}}><Text style={{color: '#eebc47'}}>3</Text></View>
                                    </View>
                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('chatConv')} style={{flex:1 , width:'100%'}}>
                                        <Body style={{borderWidth:1 , borderRadius:50 , borderColor: '#eee', marginLeft:0 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                                <Text style={{color: '#eebc47', fontSize: 15}}>اوامر الشبكة</Text>
                                                <Text note style={{color: '#868686',fontSize: 13,}}>مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                                <Text note style={{ color: '#bbb',fontSize: 13 , alignSelf:'flex-end'}}>منذ 3 ساعات</Text>
                                                <TouchableOpacity style={{backgroundColor:'#eee' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:-3 ,justifyContent:'center' , alignItems:'center' , top:5}}>
                                                    <Icon name={'close'} type='EvilIcons' style={{ color: '#eebc47' , fontSize: 17 }}  />
                                                </TouchableOpacity>
                                        </Body>
                                </TouchableOpacity>
                                </Left>
                            </CardItem>
                        </Card>
                        <Card transparent >
                            <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                                <Left>
                                    <View>
                                        <Thumbnail style={{height:70, width:70 , borderRadius:50}} source={require('../../assets/images/profile.png')}/>
                                        <View style={{backgroundColor:'#fff' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:0,justifyContent:'center' , alignItems:'center'}}><Text style={{color: '#eebc47'}}>3</Text></View>
                                    </View>
                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('chatConv')} style={{flex:1 , width:'100%'}}>
                                        <Body style={{borderWidth:1 , borderRadius:50 , borderColor: '#eee', marginLeft:0 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                                <Text style={{color: '#eebc47', fontSize: 15}}>اوامر الشبكة</Text>
                                                <Text note style={{color: '#868686',fontSize: 13,}}>مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                                <Text note style={{ color: '#bbb',fontSize: 13 , alignSelf:'flex-end'}}>منذ 3 ساعات</Text>
                                                <TouchableOpacity style={{backgroundColor:'#eee' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:-3 ,justifyContent:'center' , alignItems:'center' , top:5}}>
                                                    <Icon name={'close'} type='EvilIcons' style={{ color: '#eebc47' , fontSize: 17 }}  />
                                                </TouchableOpacity>
                                        </Body>
                                </TouchableOpacity>
                                </Left>
                            </CardItem>
                        </Card>
                        <Card transparent >
                            <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                                <Left>
                                    <View>
                                        <Thumbnail style={{height:70, width:70 , borderRadius:50}} source={require('../../assets/images/profile.png')}/>
                                        <View style={{backgroundColor:'#fff' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:0,justifyContent:'center' , alignItems:'center'}}><Text style={{color: '#eebc47'}}>3</Text></View>
                                    </View>
                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('chatConv')} style={{flex:1 , width:'100%'}}>
                                        <Body style={{borderWidth:1 , borderRadius:50 , borderColor: '#eee', marginLeft:0 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                                <Text style={{color: '#eebc47', fontSize: 15}}>اوامر الشبكة</Text>
                                                <Text note style={{color: '#868686',fontSize: 13,}}>مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                                <Text note style={{ color: '#bbb',fontSize: 13 , alignSelf:'flex-end'}}>منذ 3 ساعات</Text>
                                                <TouchableOpacity style={{backgroundColor:'#eee' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:-3 ,justifyContent:'center' , alignItems:'center' , top:5}}>
                                                    <Icon name={'close'} type='EvilIcons' style={{ color: '#eebc47' , fontSize: 17 }}  />
                                                </TouchableOpacity>
                                        </Body>
                                </TouchableOpacity>
                                </Left>
                            </CardItem>
                        </Card>
                        <Card transparent >
                            <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                                <Left>
                                    <View>
                                        <Thumbnail style={{height:70, width:70 , borderRadius:50}} source={require('../../assets/images/profile.png')}/>
                                        <View style={{backgroundColor:'#fff' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:0,justifyContent:'center' , alignItems:'center'}}><Text style={{color: '#eebc47'}}>3</Text></View>
                                    </View>
                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('chatConv')} style={{flex:1 , width:'100%'}}>
                                        <Body style={{borderWidth:1 , borderRadius:50 , borderColor: '#eee', marginLeft:0 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                                <Text style={{color: '#eebc47', fontSize: 15}}>اوامر الشبكة</Text>
                                                <Text note style={{color: '#868686',fontSize: 13,}}>مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                                <Text note style={{ color: '#bbb',fontSize: 13 , alignSelf:'flex-end'}}>منذ 3 ساعات</Text>
                                                <TouchableOpacity style={{backgroundColor:'#eee' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:-3 ,justifyContent:'center' , alignItems:'center' , top:5}}>
                                                    <Icon name={'close'} type='EvilIcons' style={{ color: '#eebc47' , fontSize: 17 }}  />
                                                </TouchableOpacity>
                                        </Body>
                                </TouchableOpacity>
                                </Left>
                            </CardItem>
                        </Card>
                        <Card transparent >
                            <CardItem style={{paddingTop:0 , paddingBottom:5}}>
                                <Left>
                                    <View>
                                        <Thumbnail style={{height:70, width:70 , borderRadius:50}} source={require('../../assets/images/profile.png')}/>
                                        <View style={{backgroundColor:'#fff' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:0,justifyContent:'center' , alignItems:'center'}}><Text style={{color: '#eebc47'}}>3</Text></View>
                                    </View>
                                    <TouchableOpacity onPress={() => this.props.navigation.navigate('chatConv')} style={{flex:1 , width:'100%'}}>
                                        <Body style={{borderWidth:1 , borderRadius:50 , borderColor: '#eee', marginLeft:0 , paddingHorizontal:15 , paddingVertical:10 , flex:1}} >
                                                <Text style={{color: '#eebc47', fontSize: 15}}>اوامر الشبكة</Text>
                                                <Text note style={{color: '#868686',fontSize: 13,}}>مثال لنص مثال لنص مثال لنص مثال لنص</Text>
                                                <Text note style={{ color: '#bbb',fontSize: 13 , alignSelf:'flex-end'}}>منذ 3 ساعات</Text>
                                                <TouchableOpacity style={{backgroundColor:'#eee' , borderRadius:50 , borderWidth:1 , borderColor:'#eee' , position:'absolute' , width:20 , height:20 , right:-3 ,justifyContent:'center' , alignItems:'center' , top:5}}>
                                                    <Icon name={'close'} type='EvilIcons' style={{ color: '#eebc47' , fontSize: 17 }}  />
                                                </TouchableOpacity>
                                        </Body>
                                </TouchableOpacity>
                                </Left>
                            </CardItem>
                        </Card>
                    </View>
                </Content>
            </Container>
        )
    }
}

const styles={
 
};

export default Chat;